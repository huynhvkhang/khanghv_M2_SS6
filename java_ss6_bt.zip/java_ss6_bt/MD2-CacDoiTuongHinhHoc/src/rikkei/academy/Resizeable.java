package rikkei.academy;

public interface Resizeable {

    abstract void resize(double percent);
}
